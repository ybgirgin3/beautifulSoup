from collections import Counter
import json
import os

filename = "merged_file.json"

def readJson(filename):
    def allPerc(ret):
        ret = json.loads(ret)

        json1 = ret[0]['freq']
        json2 = ret[2]['freq']

        counter1 = Counter(json1).most_common(10)
        counter2 = Counter(json2).most_common(10)

        allPerc = len(set(counter1) & set(counter2)) / float(len(set(counter1) | set(counter2))) * 100

        #print(allPerc)
        return allPerc

    with open(filename, "r") as f:
        ret = f.read()
        ret = json.load(ret)
        asd = allPerc(ret)
        lastJson = json.loads(ret)[1]
        lastJson.append(asd)





    
