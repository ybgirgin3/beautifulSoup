import glob

read_files = glob.glob("*.json")
print(type(read_files))
print(read_files)
