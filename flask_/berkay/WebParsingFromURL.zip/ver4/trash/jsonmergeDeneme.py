from pprint import pprint
from jsonmerge import merge
base = {
        "foo": 1,
        "bar": [ "one" ],
        }


head = {
        "bar": [ "two" ],
        "baz": "Hello, world!"
        }


result = merge(base, head)
pprint(result, width=40)
