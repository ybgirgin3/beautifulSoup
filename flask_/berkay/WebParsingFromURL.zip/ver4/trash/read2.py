import json
import glob

read_files = glob.glob("*.json")
output_list = []

for f in read_files:
    with open(f, "r") as infile:
        print(type(infile))
        #koutput_list.append(json.load(infile))
#print(output_list)

#with open("merged_file.json", "w") as outfile:
    #json.dump(output_list, outfile,  ensure_ascii=False)
