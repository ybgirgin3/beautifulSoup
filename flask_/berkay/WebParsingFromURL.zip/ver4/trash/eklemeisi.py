from collections import Counter 
import json

# function to add to JSON
def write_json(data, filename='merged_file.json'):
    with open(filename,'w') as f:
        json.dump(data, f, indent=4)
      
def allPerc(data):
    ret = json.loads(data)

    json1 = ret[0]['freq']
    json2 = ret[1]['freq']

    counter1 = Counter(json1).most_common(10)
    counter2 = Counter(json2).most_common(10)

    allPerc = len(set(counter1) & set(counter2)) / float(len(set(counter1) | set(counter2))) * 100

    #print(allPerc)
    return allPerc


     
# json dosyasını oku
with open("merged_file.json", "r") as f:
    ret = f.read()

    # jsonify the str
    jsoned = json.loads(ret)

    # get value to add
    val = allPerc(ret)

    temp = jsoned[1]
    temp['allPerc'] = val 

write_json(ret)
