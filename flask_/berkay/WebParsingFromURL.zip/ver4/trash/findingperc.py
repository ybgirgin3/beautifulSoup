from pprint import pprint
import json
from collections import Counter


def readJson(filename):
    with open(filename, 'r') as f:
        ret = f.read()

    return json.loads(ret)

json1 = readJson('belgeler.json')
json2 = readJson('chip.json')

#print(type(json1))
#pprint(json1['freq'])
c1 = Counter(json1['freq'])
#mostc1 = c1.most_common(10)
mostc1 = ["ve","İnceleme","işareti","CHIP","nasıl","yapılır?","Teknoloji","The","Zoom","bir"]


c2 = Counter(json2['freq'])
#mostc2 = c2.most_common(10)
mostc2 = ["/","2021","ve","Şubat","İnceleme","Mart","bir","Galaxy","yeni","İşte"]

ret = len(set(mostc1)&set(mostc2)) / float(len(set(mostc1) | set(mostc2))) * 100
print(ret)
#print(type(mostc2))
#json1 = json.dumps(json1, sort_keys=True)
#json2 = json.dumps(json2, sort_keys=True)


