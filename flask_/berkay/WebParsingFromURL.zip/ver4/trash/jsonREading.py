import os
import json
from pprint import pprint
from jsonmerge import Merger



jsonFileName = []
for i in os.listdir("."):
    if os.path.splitext(i)[-1] == ".json":
        jsonFileName.append(i)


inf1 = json.loads(open(jsonFileName[0], 'r').read())
inf2 = json.loads(open(jsonFileName[1], 'r').read())

#print(json.dumps(inf1, indent=4, sort_keys=True))

"""
print(f"inf1: {json.dumps(inf1, indent=4, sort_keys=True)}")
print(f"inf2: {json.dumps(inf2, indent=4, sort_keys=True)}")
schema = {
         "properties": {
             "bar": {
                 "mergeStrategy": "append"
             }
         }
     }



merger = Merger(schema)

result = merger.merge(inf1, inf2)
pprint(result, width=40)
"""

