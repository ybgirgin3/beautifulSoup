import sys
from urllib.parse import urlsplit

def fileNameCreate(url):
    url_pars = urlsplit(url)
    if url_pars[0] == 'https':
        name = url_pars[1]
        name = name.split(".")
        if name[0] == "www":
            return name[1]
        else:
            return name[0]

#ret = fileNameCreate('https://www.geeksforgeeks.org/must-do-coding-questions-for-product-based-companies/')
ret = fileNameCreate(sys.argv[1])
print(ret)
