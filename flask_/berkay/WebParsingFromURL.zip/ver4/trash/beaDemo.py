from bs4 import BeautifulSoup
import sys
from urllib.request import urlopen

html = urlopen(sys.argv[1]).read()
soup = BeautifulSoup(html, features="html.parser")

print(soup)
